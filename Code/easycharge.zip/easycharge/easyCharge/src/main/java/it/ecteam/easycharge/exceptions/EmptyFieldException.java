package it.ecteam.easycharge.exceptions;

public class EmptyFieldException extends Exception {

    public EmptyFieldException(String message) {
        super(message);
    }
}