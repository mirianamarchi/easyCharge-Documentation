package it.ecteam.easycharge.viewcontroller;

import java.io.IOException;

public interface GraphicChangeAction {

    public void act() throws IOException;

}
