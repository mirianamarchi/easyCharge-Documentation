package it.ecteam.easycharge.utils;

public enum Roles {
    USER,
    BUSINESS;
}
