package it.ecteam.easycharge.utils;

public class SessionUserFactory {

    public SessionUser createSessionUser() {
        return new SessionUser();
    }

}
