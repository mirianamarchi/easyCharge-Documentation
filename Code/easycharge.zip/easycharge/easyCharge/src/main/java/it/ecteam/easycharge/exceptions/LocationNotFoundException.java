package it.ecteam.easycharge.exceptions;

public class LocationNotFoundException extends Exception{

	public LocationNotFoundException(String message) {
		super(message);
	}
}
